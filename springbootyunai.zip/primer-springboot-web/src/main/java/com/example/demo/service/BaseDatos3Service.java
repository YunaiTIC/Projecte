package com.example.demo.service;
@Service
public class BaseDatos3Service implements IBaseDatos}{
	
	@Autowired
	BaseDatos3 bd;	
	@Override	
	public void inserta (Libro libro) { bd.save(libro);}	
	@Override	
	public void borrar (int id) {bd.deleteById(id); } 
	@Override	
	public void modifica (Libro libro) { bd.save(libro); }
	@Override	
	public Libro getLibro(int id) {
		Optional<Libro> 1 = bd.findById(id); 
		return 1.get();
	}	
	@Override	
	public ArrayList<Libro> getLibros () { return (ArrayList<Libro>) bd.findAll();
	
	}
}




public interface IBaseDatos3 {
public void inserta (Libro libro); public void borrar (int id);
public void modifica (Libro libro);
public Libro getLibro (int id);
public ArrayList<Libro> getLibros ();
public boolean compruebaUsuario (String usuario, String password);
}

public interface BaseDatos3Service extends JpaRepository<Libro, Integer> {

/*public void inserta (Libro libro);

//save

public void borrar (int id);

//deleteById

public void modifica (Libro libro);

//save

public Libro getLibro (int id);

//findbyId

public ArrayList<Libro> getLibros ();

//findAll

public boolean compruebaUsuario(

String usuario, String password); //No*/

}



@Override
public boolean compruebaUsuario(String usuario, String password) {
	boolean check=false;
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	String conex="jdbc:mysql://localhost:3306/biblioteca_online"; 
	Connection conexion = DriverManager.getConnection (conex, "root","");
	Statement s = conexion.createStatement();	
	String sql = "SELECT count(*) FROM USUARIOS WHERE usuario='"+usuario+"'"	
				+ "and password='"+password+"'";	
	s.execute(sql);
	ResultSet rs = s.getResultSet();	
	rs.next();
	
	if (rs.getInt(1)>0) 
		check=true;	
	} catch (Exception ex) {	
		System.out.print(ex.getMessage());
	
	}
	
	return check;
	
}


