package com.example.demo.repository;

import com.example.demo.bean.Libro;

public interface BaseDatos3 extends JpaRepository<Libro, Integer>{
	
	
}